<?php

$mysqli = new mysqli("localhost","root","","track");
$stmt = $mysqli -> prepare("INSERT INTO users (lat,apt,mobile,situation) VALUES (?,?,?,?)");
$lat="31.278659073351044";
$lng="75.77961676850697";
$mobile=$_POST['mobile'];
$situation= $_POST['situation'];
$stmt -> bind_param('ssss', $lat, $lng, $mobile, $situation);
$stmt->execute();
echo "inserted";
// $sql ="update "
header("website.php");
exit();
?>