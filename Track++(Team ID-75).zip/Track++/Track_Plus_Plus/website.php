<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tracking Website</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        .nav{
            background-color:#3b4d61;
        }
        .body{
            background-color:white;
            color:black;
        }
     </style>
     <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCRkDWeYa1MELCUuwArJfxqtUdUZ_r_tUQ&callback=initMap"
  type="text/javascript"></script>
  <style type="text/css">

  	#map {
  			width: 1450px;
  			height: 700px;
  	 }
  </style>

  <script type="text/javascript">

  		x = navigator.geolocation;

  		x.getCurrentPosition(success, failure);

  		function success(position)

  		{
  			var myLat = position.coords.latitude;
  			var myLong = position.coords.longitude;

  			//alert(myLat);

  			var coords = new google.maps.LatLng(myLat,myLong);

  			var mapOptions = {

  				zoom:11,
  				center: coords,
  				mapTypeId: google.maps.MapTypeId.ROADMAP
  			}

  			var map = new google.maps.Map(document.getElementById("map"), mapOptions);
  			var marker = new google.maps.Marker({map:map, position:coords});	
  		}

  		function failure(){ }

  </script>

</head>

<body class="body" style="color:black;">
    <header style="background-color:#3b4d61">
        
        <ul class="nav">
        <a href="#" class="logo" style="color:white"><span>Track</span>++</a>
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About</a></LI>
            <li><a href="#games">Registered Hospitals</a>
            <li><a href="#contact">Contact</a>
            <li><a href="UserRgisterationForm.php" >Book an Ambulance</a>
        </ul>
        <div class="action">
            <div class="searchBx">
                <a href="#"><i class='bx bx-search'></i></a>
                <input type="text" placeholder="Search Hospitals">
            </div>
        </div>
        <div class="toggleMenu" onclick="toggleMenu();"></div>
    </header>

    <!--Home Banner-->
    <div class="banner animeX" id="home">
        <div class="bg">
            <div class="content">
                <h2  style="color:#3b4d61">Book<br>
                Emergency Ambulance</h2>
                <p style="color:#3b4d61">If you are facing any MEDICAL EMERGENCY kindly Click on button below to book an ambulance</p>
                <a href="UserRgisterationForm.php" class="btn" >Book Ambulance</a>
            </div>
            <img src="images/ambulance1.jpg" height="500px" width="800px">
        </div>
    </div>

    <!--about-->
    <div class="about animeX" id ="about">
        <div class="contentBx">
            <h2>About Us</h2>
            <p style="color:#3b4d61">
                We provide services to people in rural as well as urban areas by making the ambulance available throughout the day. Various hospitals has been registered with our website.
                Our website is basically created to help users facing medical emergency to book the nearest available Hospital based upon the location. 
            </p>
            
        </div>
        <img src="images\operate.jpg" height="400px" width="700px">
    </div>

    <!--Games-->
    <div class="games animeX" id ="games">
        <h2>Popular Hospitals</h2>
        
        <div class="cardBx">
            <div class="card" data-item="pc">
                <img src="images\photo1.jfif">
                <div class="content">
                    <h4>Tinshukia Hospital</h4>
                    
                    <div class="info">
                      
                        <a href="http://tinsukiacivilhospital.in/">Visit Website</a>
                    </div>
                </div>
            </div>

            <div class="card " data-item="pc">
                <img src="images\varun.jpg">
                <div class="content">
                    <h4>Varun Hispital</h4>
                    <div class="info">
                        
                        <a href="https://www.varungroup.com/vhc">Visit Website</a>
                    </div>
                </div>
            </div>

            <div class="card" data-item="pc">
                <img src="images\civil.jfif">
                <div class="content">
                    <h4>Civil Hospital</h4>
                    <div class="info">
                        <a href="https://kapurthala.gov.in/public-utility/civil-hospital-phagwara/">Visit Website</a>
                    </div>
                </div>
            </div>

            <div class="card" data-item="pc">
                <img src="images\chiranjiv.jfif">
                <div class="content">
                    <h4>Chiranjeevi Hospital</h4>
                    <div class="info">
                        <a href="https://chiranjeevhospital.com/">Visit Website</a>
                    </div>
                </div>
            </div>

            <div class="card" data-item="pc">
                <img src="images\92f18978-5005-4db2-82b2-22612503709e.jfif">
                <div class="content">
                    <h4>NHS</h4>
                    <div class="info">
                        <a href="https://nhshospital.in/">Visit Website</a>
                    </div>
                </div>
            </div>

            <div class="card" data-item="Mobile">
                <img src="images\virak.jfif">
                <div class="content">
                    <h4>Virak HOspital</h4>
                    <div class="info">
                        <a href="https://virkhospitals.com/">Visit Website</a>
                    </div>
                </div>
            </div> 

            
        </div>
    </div>

    <div id="map"></div> 
        <!--Contact-->
        <form acton="" method="post">
        <div class="contact animeX" id="contact">
            <img src="images\contact.jpg" >
            
            <div class="form">
                <h1>Contact Us</h1>
                <div class="inputBx">
                <p>Enter Name</p>
                    <input type="text" placeholder="Full Name" name="uname">    
            </div>
            <div class="inputBx">
            <p>Enter Email</p>
                <input type="email" placeholder="Enter your email" name="email">    
            </div>
            <div class="inputBx">
            <p>Messages</p>
                <textarea placeholder="Type here..." name="mess"></textarea>   
            </div>
            <div class="inputBx">
                <input type="submit" name="Submit" value="Submit">                        
            </div>
            </div>

        </div>
        </form>
        <?php
        $conn = mysqli_connect("localhost","root","","track") or die("cannot connect to datatbase".mysqli_connect_error());
        if( isset($_POST['Submit']))
        {
            $name= $_POST['uname'];
            $email=$_POST['email'];
            $message = $_POST['mess'];
            $sql ="CREATE TABLE IF NOT EXISTS FeedBack(id int primary key auto_increment, 
            user_name varchar(255),email varchar(255),message varchar(255))";
            if ($conn->query($sql) === TRUE) {
            } else {
                echo "Error creating Table 'Users': " . $conn->error;
            }

            $query = "INSERT INTO FeedBack (user_name,email, message)
    VALUES ('$name','$email','$message')";
    if( mysqli_query($conn, $query)){
    }else{
      $msg= mysqli_error($conn);
    }

            echo '<script>alert("Thank you for sharing your valuable feedback with us")</script>';
        }
       ?>

    <!--Footer-->
    <footer>
        <div class="info ">
            <a href="#" class="logo"><span></span>Track++</a>
            <p><i class='bx bx-copyright'></i>2022 All Rights Reserved</p>
            <ul>
                <li><a href="#"><i class='bx bxl-facebook'></i></a></li>
                <li><a href="#"><i class='bx bxl-instagram'></i></a></li>
                <li><a href="#"><i class='bx bxl-twitter'></i></a></li>
                <li><a href="#"><i class='bx bxl-youtube'></i></a></li>
            </ul>
        </div>
    </footer>

    <script>
        /* sticky navbar */
        window.addEventListener('scroll', function () {
            var header = document.querySelector('header');
            header.classList.toggle('sticky', window.scrollY > 0);
        });

        // responsive navbar/
        function toggleMenu(){
             const toggleMenu =document.querySelector('.toggleMenu');
             console.log(toggleMenu);
             const nav = document.querySelector('.nav');
             toggleMenu.classList.toggle('active');
             nav.classList.toggle('active');

        }
        //  s rolling animation effects 

        window.addEventListener('scroll', function() {
            var anime=document.querySelectorAll('.animeX');


            for(var s=0; s<anime.length; s++) {
                var windowheight =window.innerHeight;
                var animetop= anime[s].getBoundingClientRect().top;
                var animepoint=150;

            if(animetop < windowheight - animepoint) {
                anime[s].classList.add('active');
            }
            else {
                anime[s].classList.remove('active');
            }
            }
        })

    </script>
</body>

</html>