<?php
$conn= mysqli_connect("localhost","root","","track");
if(!$conn){
    echo "connection not created";
   die("not connected");
}else{
    echo "connection established";
}
$sql ="create table users(id int primary key auto_increment, lat varchar(255), apt varchar(255), situation varchar(255))";
if(mysqli_query($conn,$sql))
echo "users created";
else {echo " cannot create table users";
echo die(mysqli_connect_error());}
$sql2 ="create table  hospital(id int primary key auto_increment, lat varchar(255), apt varchar(255), name varchar(255) ,totalamb int,mobile varchar(10))";
if(mysqli_query($conn,$sql2))
echo "hospital created";
else  echo "cannot create table hospital";


?>