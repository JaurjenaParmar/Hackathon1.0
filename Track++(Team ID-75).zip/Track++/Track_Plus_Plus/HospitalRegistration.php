<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>HospitalRegistrationTrack++</title>
</head>

<body class="container">
    <div class="container text-center rounded-5  border" style="width:800px;height:500px ;margin-top:60px; box-shadow:10px 10px 10px 10px;">

        <div class="m-50 text-center container row " style="margin-top:50px;" >
            <h1>Regsiter Hospital</h1>
        </div>
        <form method="post" action="" class="was-validated">
        <script>
                    if(!navigator.geolocation){
                        throw new Error("No Geolocation Available");
                    }
                    function success(pos){
                        const lat=pos.coords.latitude;
                        const lng=pos.coords.longitude;
                        
                    }
                    function error(){
                
                    }
                    const options={};
                    navigator.geolocation.getCurrentPosition(success,error,options);
                
            </script>
            <div class="form-floating mb-3 mt-3 ">
                <input type="text" class="form-control " id="name" placeholder="Enter Hospital Name" name="name" required>
                <label for="name">Hospital Name</label>
            </div>
            
            <div class="form-floating mb-3 mt-3">
                <input type="number" class="form-control" id="ambulance" placeholder="Enter Ambulance Count"
                    name="ambulance" required>
                <label for="ambulance">Total Ambulance</label>
            </div>
            <div class="form-floating mb-3 mt-3">
                <input type="tel" class="form-control" id="mobile" placeholder="Enter Mobile Number" pattern="[0-9]{3}[0-9]{3}[0-9]{4}"  name="mobile" required> 
                <label for="mobile">Mobile Number</label>
            </div>
            <div class="mb-3">
                <input type="button" value="Register" name="register" class="btn btn-primary">
            </div>
        </form>
</body>
<?php
if(isset($_Post['register']))
{
    echo "<script>alert('submite');</script>";
}
?>

</html> 
