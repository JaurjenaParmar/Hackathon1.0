<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>UserRegistrationTrack++</title>
</head>
<body class="bg-info">

    <div class="container text-center rounded-5  border border-primary"  style="width:800px;margin-top:200px; background-color:white; opacity: 0.8;">
    
        <form action="list.php" method="post" class="was-validated" >
            <div class="form-floating mb-3 mt-3 ">
            <script>
                    if(!navigator.geolocation){
                        throw new Error("No Geolocation Available");
                    }
                    function success(pos){
                        const lat=pos.coords.latitude;
                        const lng=pos.coords.longitude;
                        // document.getElementById("lat").innerText=lat;
                        // document.getElementById("lng").innerText=lng;
                    }
                    function error(){
                
                    }
                    const options={};
                    navigator.geolocation.getCurrentPosition(success,error,options);
                
                </script>
                
            </div>
             <!-- <span id="lat" class="text-info"></span>
             <span id ="lng" class="text-info"></span> -->
            <div class="form-floating mb-3 mt-3">

                <input type="tel" class="form-control" id="mobile" pattern="[0-9]{3}[0-9]{3}[0-9]{4}"  placeholder="Enter Mobile Number" name="mobile" required>
                <label for="mobile">Mobile Number</label>
            </div>
            <div class="form-floating mb-3 mt-3 ">
            <textarea  class="form-control" name="situation" id="situation" cols="50" rows="5" placeholder="Enter the Emergency condition like: accident/heart Attack etc." required></textarea>
            <label for="situation">Enter Emergency Situation</label>
            </div>
            <input type="submit" value="Book Ambulance" name="book" class="btn btn-primary mb-3">
            
        </form>
        


    </div>
    
</body>
</html>